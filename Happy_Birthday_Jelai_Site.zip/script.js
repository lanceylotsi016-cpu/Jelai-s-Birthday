document.addEventListener('DOMContentLoaded', () => {
  const petals = 30;
  for (let i = 0; i < petals; i++) {
    let petal = document.createElement('div');
    petal.classList.add('petal');
    petal.style.left = Math.random() * 100 + 'vw';
    petal.style.animationDuration = (5 + Math.random() * 5) + 's';
    petal.style.animationDelay = Math.random() * 5 + 's';
    document.body.appendChild(petal);
  }
});

const style = document.createElement('style');
style.textContent = \`
.petal {
  position: fixed;
  top: -10px;
  width: 15px;
  height: 15px;
  background: rgba(255, 182, 193, 0.9);
  border-radius: 50%;
  animation-name: fall;
  animation-timing-function: linear;
  animation-iteration-count: infinite;
}
@keyframes fall {
  to {
    transform: translateY(110vh) rotate(360deg);
    opacity: 0.5;
  }
}
\`;
document.head.appendChild(style);
